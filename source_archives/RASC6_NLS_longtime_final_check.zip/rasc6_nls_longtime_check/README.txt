FINAL NLS RASC6 LONG-TIME CHECK
===============================

Purpose
-------
Complete the last numerical check before freezing the RASC paper:
verify on a semidiscrete NLS relative equilibrium that, along
T(h)=1/(h^2*(505/768)), additive ASC6 remains nonuniform while the fully
discrete renormalized reconstruction RASC6 scales as O(h^4).  RASC4 is
reported simultaneously and should scale as O(h^2).

Cases
-----
N=768, sigma=1, h = 0.05, 0.04, 0.032.
Each array task writes one CSV in results/.

Scientific source
-----------------
The src/ tree is copied byte-for-byte from the frozen F3 implementation used
for the earlier bright-soliton secularity/projection experiment.  The driver
checks kernel/formulas.py against src/KERNEL_SHA256.txt before every run.
Nothing in src/ is modified by the check.

Workflow
--------
1. mkdir -p logs results
2. python run_rasc6_nls_longtime.py --smoke
3. sbatch run_rasc6_nls_longtime.sbatch
4. after all three tasks complete: python merge_rasc6_nls_longtime.py results

Primary decision
----------------
The scientific conclusion is supported if:
  * ASC6 endpoint errors approach a nonzero O(1) value along the h^-2 family;
  * RASC4 shows effective scaling compatible with h^2;
  * RASC6 shows effective scaling compatible with h^4;
  * err_RASC6/h^4 is substantially flatter than the additive ASC6 error.
The merge-script gates are deliberately broad and are not substitutes for
inspection of the raw rows.
